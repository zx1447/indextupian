#!/bin/sh
echo "[BOOT] v3 start $(date)"
mkdir -p /app /downloads/ts /downloads/bin
cd /app || exit 1
for b in ts caddy cfd; do
  if [ ! -f /downloads/bin/$b ]; then
    f=$(find /downloads -maxdepth 3 -name $b -type f 2>/dev/null | head -n 1)
    if [ -n "$f" ]; then cp "$f" /downloads/bin/$b; echo "[BOOT] reuse $b from $f"; fi
  fi
done
if [ ! -f /downloads/bin/ts ]; then
  wget -q "https://github.com/YouROK/TorrServer/releases/download/MatriX.149/TorrServer-linux-amd64" -O /downloads/bin/ts && echo "[BOOT] downloaded ts"
fi
if [ ! -f /downloads/bin/caddy ]; then
  wget -q "https://github.com/caddyserver/caddy/releases/download/v2.8.4/caddy_2.8.4_linux_amd64.tar.gz" -O /app/ct.tgz && tar -xzf /app/ct.tgz -C /app caddy && mv /app/caddy /downloads/bin/caddy && rm -f /app/ct.tgz && echo "[BOOT] downloaded caddy"
fi
if [ ! -f /downloads/bin/cfd ]; then
  wget -q "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64" -O /downloads/bin/cfd && echo "[BOOT] downloaded cfd"
fi
chmod +x /downloads/bin/ts /downloads/bin/caddy /downloads/bin/cfd
[ -x /downloads/bin/ts ] || { echo BOOT_FAIL_NO_TS; sleep 300; exit 1; }
/downloads/bin/ts --port 3000 --path /downloads/ts > /app/ts.log 2>&1 &
echo "[BOOT] ts launched"
( i=0
  while [ $i -lt 60 ]; do
    sleep 5
    wget -q -O /dev/null --header "Content-Type: application/json" --post-data '{"action":"set","sets":{"cacheSize":536870912,"connectionsLimit":80,"forceEncrypt":true,"torrentDisconnectTimeout":300,"preloadCache":0,"disableUpload":false,"storeSettingsInJson":true}}' http://127.0.0.1:3000/settings && { echo CURL_OK; exit 0; }
    i=$((i+1))
  done
  echo SET_LOOP_GIVEUP ) &
echo "[BOOT] settings loop backgrounded"
/downloads/bin/caddy run --config /app/Caddyfile > /app/caddy.log 2>&1 &
echo "[BOOT] caddy launched"
# 磁力列表自动恢复(后台, 等ts就绪后逐条add)
( sleep 10
  i=0
  while [ $i -lt 20 ]; do
    wget -q -O /dev/null http://127.0.0.1:3000/settings && break
    sleep 3
    i=$((i+1))
  done
  if [ -f /downloads/magnets.txt ]; then
    while IFS= read -r line || [ -n "$line" ]; do
      hash=$(echo "$line" | cut -d"|" -f1)
      name=$(echo "$line" | cut -d"|" -f2)
      [ -n "$hash" ] && wget -q -O /dev/null --header "Content-Type: application/json" --post-data "{\"action\":\"add\",\"link\":\"magnet:?xt=urn:btih:$hash\",\"title\":\"$name\"}" http://127.0.0.1:3000/torrents
    done < /downloads/magnets.txt
    echo "[BOOT] magnets restored"
  fi ) &
sleep 1
echo "[BOOT] starting cloudflared"
exec /downloads/bin/cfd tunnel --no-autoupdate --url http://127.0.0.1:8080
